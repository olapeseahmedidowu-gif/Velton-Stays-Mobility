VELTON STAYS & MOBILITY — FULL WEBSITE PACKAGE

Included:
- index.html — homepage
- services.html — services overview
- property-owners.html — property owner services
- mobility.html — mobility services
- about.html — company overview
- contact.html — enquiry and contact page
- assets/style.css — responsive design and brand styling
- assets/site.js — navigation and interaction
- assets/velton-logo.png — your supplied logo, placed without alteration

BEFORE PUBLISHING
1. WhatsApp number is already set (2349165714134) in assets/site.js.
2. Replace sample stock photography with real, approved property and vehicle images when available; do not present stock photos as Velton's actual inventory.
3. Review all service statements, terms and availability claims before launch.
4. Test every page, form and mobile layout.
5. Connect your domain and publish using Netlify, Vercel or another static host.

IMPORTANT
This is a responsive static website, not a live booking platform. It does not include live availability, payment processing, a booking database, user accounts or an admin dashboard. Enquiry features use email/WhatsApp handoff and require valid contact details. Properties, vehicles and service arrangements remain subject to confirmation and availability.
